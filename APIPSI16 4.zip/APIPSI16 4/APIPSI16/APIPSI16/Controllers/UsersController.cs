﻿using APIPSI16.Data;
using APIPSI16.Filters;
using APIPSI16.Models;
using APIPSI16.Models.DTOs;
using APIPSI16.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace APIPSI16.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize] // Require JWT for all actions
    public class UsersController : ControllerBase
    {
        private readonly xcleratesystemslinks_SampleDBContext _context;
        private readonly IFileStorageService _fileStorage;

        public UsersController(xcleratesystemslinks_SampleDBContext context, IFileStorageService fileStorage)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
            _fileStorage = fileStorage ?? throw new ArgumentNullException(nameof(fileStorage));
        }

        // GET: api/Users
        // - If no filters supplied: Admin (0) only -> returns all users
        // - If filters supplied (jobPreference and/or nationality): Admin (0) and Employer (2) can query
        [HttpGet]
        public async Task<IActionResult> GetUsers([FromQuery] int? jobPreference, [FromQuery] int? nationality)
        {
            var userRole = GetCurrentUserRole();

            if (jobPreference.HasValue || nationality.HasValue)
            {
                if (userRole != "0" && userRole != "2")
                    return Forbid();

                IQueryable<User> q = _context.Users;

                if (jobPreference.HasValue)
                    q = q.Where(u => u.JobPreference == jobPreference.Value);

                if (nationality.HasValue)
                    q = q.Where(u => u.Nationality == nationality.Value);

                var filtered = await q
                    .Select(u => new UserDTO
                    {
                        UserId = u.UserId,
                        Name = u.Name,
                        Email = u.Email,
                        Nationality = u.Nationality,
                        JobPreference = u.JobPreference,
                        ProfileBio = u.ProfileBio,
                        DoB = u.DoB,
                        PhoneNumber = u.PhoneNumber,
                        ProfilePictureUrl = u.ProfilePictureUrl
                    })
                    .ToListAsync();

                return Ok(filtered);
            }

            if (userRole != "0")
                return Forbid();

            var users = await _context.Users
                .Select(u => new UserDTO
                {
                    UserId = u.UserId,
                    Name = u.Name,
                    Email = u.Email,
                    Nationality = u.Nationality,
                    JobPreference = u.JobPreference,
                    ProfileBio = u.ProfileBio,
                    DoB = u.DoB,
                    PhoneNumber = u.PhoneNumber,
                    ProfilePictureUrl = u.ProfilePictureUrl
                })
                .ToListAsync();

            return Ok(users);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetUser(int id)
        {
            var user = await _context.Users
                .Where(u => u.UserId == id)
                .Select(u => new UserDTO
                {
                    UserId = u.UserId,
                    Name = u.Name,
                    Email = u.Email,
                    Nationality = u.Nationality,
                    JobPreference = u.JobPreference,
                    ProfileBio = u.ProfileBio,
                    DoB = u.DoB,
                    PhoneNumber = u.PhoneNumber,
                    Role = u.Role,
                    ProfilePictureUrl = u.ProfilePictureUrl
                })
                .FirstOrDefaultAsync();

            if (user == null) return NotFound();

            var currentUserId = GetCurrentUserId();
            var userRole = GetCurrentUserRole();

            if (userRole != "0" && currentUserId != id)
                return Forbid();

            return Ok(user);
        }

        // GET: api/Users/5/profile
        // Get complete user profile with skills, experiences, and educations
        [HttpGet("{id}/profile")]
        public async Task<IActionResult> GetUserProfile(int id)
        {
            var user = await _context.Users.FindAsync(id);
            if (user == null) return NotFound();

            var skills = await _context.UserSkills
                .Where(us => us.UserId == id)
                .Include(us => us.Skill)
                .Select(us => new SkillDTO
                {
                    SkillId = us.SkillId,
                    Name = us.Skill.Name,
                    EndorsementCount = _context.SkillEndorsements.Count(se => se.UserSkillId == us.UserSkillId)
                })
                .ToListAsync();

            var experiences = await _context.ProfileExperiences
                .Where(pe => pe.UserId == id)
                .Select(pe => new ProfileExperienceDTO
                {
                    ExperienceId = pe.ExperienceId,
                    JobTitle = pe.Title,
                    CompanyName = pe.CompanyName,
                    StartDate = pe.StartDate,
                    EndDate = pe.EndDate,
                    Description = pe.Description
                })
                .ToListAsync();

            var educations = await _context.ProfileEducations
                .Where(pe => pe.UserId == id)
                .Select(pe => new ProfileEducationDTO
                {
                    EducationId = pe.EducationId,
                    Institution = pe.School,
                    Degree = pe.Degree,
                    FieldOfStudy = pe.FieldOfStudy,
                    StartDate = pe.StartYear.HasValue ? new DateOnly(pe.StartYear.Value, 1, 1) : (DateOnly?)null,
                    EndDate = pe.EndYear.HasValue ? new DateOnly(pe.EndYear.Value, 1, 1) : (DateOnly?)null
                })
                .ToListAsync();

            var profileDto = new UserProfileDTO
            {
                UserId = user.UserId,
                Name = user.Name,
                Email = user.Email,
                PhoneNumber = user.PhoneNumber,
                Nationality = user.Nationality,
                JobPreference = user.JobPreference,
                ProfileBio = user.ProfileBio,
                DoB = user.DoB,
                ProfilePictureUrl = user.ProfilePictureUrl,
                Skills = skills,
                Experiences = experiences,
                Educations = educations
            };

            return Ok(profileDto);
        }

        // POST: api/Users/5/upload-picture
        // Upload profile picture for a user
        [HttpPost("{id}/upload-picture")]
        [SwaggerFileUpload]
        public async Task<IActionResult> UploadProfilePicture(int id, IFormFile file)
        {
            var currentUserId = GetCurrentUserId();
            var userRole = GetCurrentUserRole();

            if (userRole != "0" && currentUserId != id)
                return Forbid();

            var user = await _context.Users.FindAsync(id);
            if (user == null) return NotFound();

            if (!_fileStorage.ValidateImageFile(file, out var errorMessage))
                return BadRequest(new { message = errorMessage });

            try
            {
                // Delete old profile picture if exists
                if (!string.IsNullOrEmpty(user.ProfilePictureUrl))
                {
                    await _fileStorage.DeleteFileAsync(user.ProfilePictureUrl);
                }

                // Save new profile picture
                var fileUrl = await _fileStorage.SaveFileAsync(file, "profiles");
                user.ProfilePictureUrl = fileUrl;
                await _context.SaveChangesAsync();

                return Ok(new { success = true, fileUrl = fileUrl, message = "Profile picture uploaded successfully" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { success = false, message = $"Error uploading file: {ex.Message}" });
            }
        }

        // POST: api/Users
        // Only admins can create users via this endpoint.
        // (Self-registration should be done through /api/Auth/register)
        [HttpPost]
        [Authorize(Roles = "0")]
        public async Task<IActionResult> CreateUser([FromBody] User user)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);

            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetUser), new { id = user.UserId }, user);
        }

        // PUT: api/Users/5
        // Admins can update any user; users can update only their own record.
        // Non-admins cannot change Role or PasswordHash through this endpoint.
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateUser(int id, [FromBody] User updated)
        {
            if (id != updated.UserId) return BadRequest();

            var existing = await _context.Users.FindAsync(id);
            if (existing == null) return NotFound();

            var currentUserId = GetCurrentUserId();
            var userRole = GetCurrentUserRole();

            // Only admin or owner can update
            if (userRole != "0" && existing.UserId != currentUserId)
                return Forbid();

            // Non-admins: only allow a subset of fields to be changed
            if (userRole != "0")
            {
                existing.Name = updated.Name;
                existing.PhoneNumber = updated.PhoneNumber;
                existing.Nationality = updated.Nationality;
                existing.JobPreference = updated.JobPreference;
                existing.ProfileBio = updated.ProfileBio;
                existing.DoB = updated.DoB;
                // Do NOT allow non-admins to change Email, Role, PasswordHash
            }
            else
            {
                // Admin can update most fields; don't automatically accept a plaintext password here
                existing.Name = updated.Name;
                existing.Email = updated.Email;
                existing.PhoneNumber = updated.PhoneNumber;
                existing.Nationality = updated.Nationality;
                existing.JobPreference = updated.JobPreference;
                existing.ProfileBio = updated.ProfileBio;
                existing.DoB = updated.DoB;
                existing.Role = updated.Role;
                // If you want admins to reset passwords, provide a dedicated endpoint that accepts a hashed password
            }

            try
            {
                _context.Entry(existing).State = EntityState.Modified;
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!UserExists(id)) return NotFound();
                throw;
            }

            return NoContent();
        }

        // DELETE: api/Users/5
        // Admin only
        [HttpDelete("{id}")]
        [Authorize(Roles = "0")]
        public async Task<IActionResult> DeleteUser(int id)
        {
            var user = await _context.Users.FindAsync(id);
            if (user == null) return NotFound();

            _context.Users.Remove(user);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool UserExists(int id)
        {
            return _context.Users.Any(u => u.UserId == id);
        }

        private int? GetCurrentUserId()
        {
            var claim = User.FindFirst(ClaimTypes.NameIdentifier);
            return claim != null && int.TryParse(claim.Value, out var id) ? id : null;
        }

        private string? GetCurrentUserRole()
        {
            return User.FindFirst(ClaimTypes.Role)?.Value;
        }
    }
}